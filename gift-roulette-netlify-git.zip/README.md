# Gift Roulette — Netlify

Deploy with GitHub on Netlify:
1. Create a new GitHub repo and upload `index.html`, `netlify.toml`, and this README.
2. In Netlify: **Add new site → Import from Git** → choose your repo.
3. **Build command**: leave empty. **Publish directory**: `.`
4. Deploy.

Cash amount in final choice can be set via URL query: `?cash=200`.
